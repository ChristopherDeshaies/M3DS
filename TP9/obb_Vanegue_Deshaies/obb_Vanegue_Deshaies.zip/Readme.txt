Vanegue elliot
Deshaies christopher

	TP Obb

	Commentaire:
		TP terminé dans son ensemble sauf la dernière question. Sujet plutôt claire.
		
	Difficulté rencontré:
		TP assez simple dans son ensemble, il n'y a eu que la question 3 de l'exercice 4 
		qui a posé des problèmes à cause qu'il fallait bien traiter tous les cas de collision.
